package com.perfection.utkarsh.wardrobe;

public class NewOutfit {
}
